import React from "react";

export default function Contact() {
    return (
        <section className="contact" id="contact">

            <span className="h-line">
                <i className="ri-shining-2-line"></i>Contact
            </span>

            {/* Main container for left + right */}
            <div className="contact-wrapper">

                {/* LEFT SIDE LIKE HTML VERSION */}
                <div className="contact-left">
                    <h2>Got a Project <span>Let's Talk</span></h2>

                    <div className="email">
                        <p>Email:</p>
                        <h6>Dipanshuroy584@gmail.com</h6>
                    </div>

                    <div className="num">
                        <p>Call:</p>
                        <h6>+91 7834868865</h6>
                    </div>

                    <div className="social-icons">
                        <a href="https://github.com/deepanshu-ku-17"><i className="ri-github-line"></i></a>
                        <a href="http://www.linkedin.com/in/deepanshu-kumar-5604b1239"><i className="ri-linkedin-line"></i></a>
                        <a href="mailto:dipanshuroy584@gmail.com"><i className="ri-mail-line"></i></a>
                        <a href="https://www.instagram.com/17_deepanshu/"><i className="ri-instagram-line"></i></a>
                    </div>
                </div>

                {/* RIGHT SIDE FORM (NETLIFY READY) */}
                <form 
                    className="contact-form"
                    name="contact-form"
                    method="POST"
                    data-netlify="true"
                >
                    {/* Netlify Hidden Input */}
                    <input type="hidden" name="form-name" value="contact-form" />

                    <input type="text" name="name" placeholder="Your Name" required />
                    <input type="email" name="email" placeholder="Email Address..." required />
                    <textarea name="message" placeholder="Write Message here..." required />

                    <button type="submit" className="submit-btn">Submit Now</button>
                </form>

            </div>
        </section>
    );
}
