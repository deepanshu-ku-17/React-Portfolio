import React from "react";
import Certificates from "../components/Certificates";

export default function CertificatePage() {
    return <Certificates />;
}
